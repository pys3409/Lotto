package com.example.myapplication

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import com.example.myapplication.databinding.ActivityMainBinding
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {

    val BallList = ArrayList<Bitmap>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // --------------------------- 랜덤 번호 -----------------------


       // ---------------------------- 랜덤 이미지 ----------------------------------

        for (i in 0..44) {
            var bmp : Int = resources.getIdentifier("lotto" + (i + 1),"drawable", packageName)
            var bitmap:Bitmap = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources,bmp),100,100,false)
            BallList.add(bitmap)
        }

        binding.lottoImage.setOnClickListener {

            var set: TreeSet<Int> = TreeSet() // 랜덤 번호가 겹치지 않도록

            while (set.size < 6){
                val random = Random()
                val num = random.nextInt(45)
                set.add(num) // set에 랜덤 번호 저장
            }

            for ((nCount, i) in set.withIndex()) {
                var tmpID : Int = resources.getIdentifier("lottoBall_" + (nCount + 1),"id",packageName)
                val imgView = findViewById<ImageView>(tmpID)
                imgView.setImageBitmap(BallList[i])
            }
        }

        // ------------------------- retrofit ----------------------------

    }
}